/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Bgm extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("blank", "./Bgm/costumes/blank.svg", { x: 0, y: 0 }),
    ];

    this.sounds = [
      new Sound(
        "game_maoudamashii_5_casino04.mp2",
        "./Bgm/sounds/game_maoudamashii_5_casino04.mp2.wav"
      ),
      new Sound(
        "game_maoudamashii_5_casino01.mp2",
        "./Bgm/sounds/game_maoudamashii_5_casino01.mp2.wav"
      ),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "GO" }, this.whenIReceiveGo),
    ];

    this.audioEffects.volume = 50;
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveGo() {
    this.stage.vars.bgmtime = this.timer;
    while (true) {
      this.audioEffects.volume = 50;
      if (this.compare(this.stage.vars.leftspins, 1) > 0) {
        yield* this.bgm(1);
      } else {
        yield* this.bgm(2);
      }
      while (
        !!(
          this.compare(this.timer, this.stage.vars.bgmtime) < 0 &&
          ((this.toNumber(this.stage.vars.bgmnum) === 1 &&
            this.compare(this.stage.vars.leftspins, 0) > 0) ||
            (this.toNumber(this.stage.vars.bgmnum) === 2 &&
              this.compare(this.stage.vars.leftspins, 2) < 0))
        )
      ) {
        yield;
      }
      for (let i = 0; i < 25; i++) {
        this.audioEffects.volume -= 2;
        yield;
      }
      yield;
    }
  }

  *bgm(bgm) {
    this.stage.vars.bgmnum = bgm;
    this.stopAllSounds();
    yield* this.startSound(bgm);
    if (this.toNumber(bgm) === 1) {
      this.stage.vars.bgmtime = this.timer + 32.5;
    } else {
      this.stage.vars.bgmtime = this.timer + 64.1;
    }
  }
}
