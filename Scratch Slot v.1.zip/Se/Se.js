/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Se extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("blank", "./Se/costumes/blank.svg", { x: 0, y: 0 }),
    ];

    this.sounds = [
      new Sound("Stop.mp3", "./Se/sounds/Stop.mp3.wav"),
      new Sound("Win.mp3", "./Se/sounds/Win.mp3.wav"),
      new Sound("lever.mp3", "./Se/sounds/lever.mp3.wav"),
      new Sound(
        "Slot Machine Jackpot Sound Effect.mp3",
        "./Se/sounds/Slot Machine Jackpot Sound Effect.mp3.wav"
      ),
      new Sound(
        "game_maoudamashii_5_casino04.mp3",
        "./Se/sounds/game_maoudamashii_5_casino04.mp3.wav"
      ),
      new Sound(
        "game_maoudamashii_5_casino01.mp3",
        "./Se/sounds/game_maoudamashii_5_casino01.mp3.wav"
      ),
    ];

    this.triggers = [
      new Trigger(Trigger.BROADCAST, { name: "HIT!" }, this.whenIReceiveHit),
      new Trigger(Trigger.BROADCAST, { name: "pull" }, this.whenIReceivePull),
      new Trigger(Trigger.BROADCAST, { name: "stop" }, this.whenIReceiveStop),
      new Trigger(
        Trigger.BROADCAST,
        { name: "WonSound" },
        this.whenIReceiveWonsound
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
    ];

    this.vars._1 = 90;
  }

  *whenIReceiveHit() {
    this.vars._1 = 0;
    while (true) {
      this.vars._1 = this.toNumber(this.vars._1) + 30;
      yield* this.startSound("Win.mp3");
      while (!!(this.compare(this.vars._1, this.stage.vars.checktime) > 0)) {
        yield;
      }
      yield;
    }
  }

  *whenIReceivePull() {
    yield* this.startSound("lever.mp3");
  }

  *whenIReceiveStop() {
    yield* this.startSound("Stop.mp3");
  }

  *whenIReceiveWonsound() {
    /* TODO: Implement stop other scripts in sprite */ null;
    yield* this.startSound("Slot Machine Jackpot Sound Effect.mp3");
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }
}
