/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Reels extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("7", "./Reels/costumes/7.svg", { x: 66, y: 83 }),
      new Costume("Scratch1", "./Reels/costumes/Scratch1.svg", {
        x: 54,
        y: 51,
      }),
      new Costume("Scratch2", "./Reels/costumes/Scratch2.svg", {
        x: 55,
        y: 51,
      }),
      new Costume("Scratch3", "./Reels/costumes/Scratch3.svg", {
        x: 55,
        y: 51,
      }),
      new Costume("WILD", "./Reels/costumes/WILD.svg", { x: 51, y: 59 }),
      new Costume("giga", "./Reels/costumes/giga.svg", { x: 57, y: 65 }),
      new Costume("pico", "./Reels/costumes/pico.svg", { x: 49, y: 59 }),
      new Costume("gobo", "./Reels/costumes/gobo.svg", { x: 47, y: 55 }),
      new Costume("bell2", "./Reels/costumes/bell2.svg", { x: 51, y: 48 }),
      new Costume("bell1", "./Reels/costumes/bell1.svg", { x: 40, y: 39 }),
      new Costume("banana", "./Reels/costumes/banana.svg", { x: 36, y: 37 }),
      new Costume("orange", "./Reels/costumes/orange.svg", { x: 47, y: 38 }),
      new Costume("respin", "./Reels/costumes/respin.svg", { x: 73, y: 72 }),
    ];

    this.sounds = [
      new Sound("Stop.mp3", "./Reels/sounds/Stop.mp3.wav"),
      new Sound("Win.mp3", "./Reels/sounds/Win.mp3.wav"),
      new Sound("lever.mp3", "./Reels/sounds/lever.mp3.wav"),
      new Sound(
        "Slot Machine Jackpot Sound Effect.mp3",
        "./Reels/sounds/Slot Machine Jackpot Sound Effect.mp3.wav"
      ),
    ];

    this.triggers = [
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.BROADCAST, { name: "HIT!" }, this.whenIReceiveHit),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "GO" }, this.whenIReceiveGo),
    ];

    this.vars._1 = 0;
    this.vars.yourreel = 5;
    this.vars.offsety = 0;
    this.vars._2 = 6;
    this.vars._3 = "b";
    this.vars._4 = 4;
    this.vars.jackpot = 0;
    this.vars.symbolscheckpos = [
      22222, 11111, 33333, 12321, 32123, 21112, 23332, 11233, 33211, 21232,
      23212, 12221, 32223, 12121, 32323, 22122, 22322, 11311, 33133, 13331,
      31113, 11211, 33233, 21212, 23232,
    ];
  }

  *clonereels(reel, _) {
    this.stage.vars.scroolys.splice(
      reel - 1,
      1,
      this.toNumber(_) * (this.size * -1.2)
    );
    this.vars.offsety = 0;
    this.vars._1 = 0;
    this.vars.yourreel = reel;
    for (let i = 0; i < 7; i++) {
      this.createClone();
      this.vars._1 =
        (this.toNumber(this.vars._1) % this.stage.vars.reel.length) + 1;
      yield;
    }
  }

  *startAsClone() {
    this.visible = true;
    this.effects.clear();
    this.goto(
      this.size * -3 +
        (this.toNumber(this.vars.yourreel) - 1) * (this.size * 1.5),
      this.toNumber(this.stage.vars.positiony) +
        (this.toNumber(
          this.itemOf(this.stage.vars.scroolys, this.vars.yourreel - 1)
        ) +
          (this.toNumber(this.vars._1) + this.toNumber(this.vars.offsety)) *
            (this.size * -1.2))
    );
    while (true) {
      this.costume =
        this.toNumber(
          "0x" +
            this.letterOf(
              this.itemOf(
                this.stage.vars.reel,
                (this.toNumber(this.vars._1) +
                  this.toNumber(this.vars.offsety)) %
                  this.stage.vars.reel.length
              ),
              this.vars.yourreel - 1
            )
        ) + 1;
      this.y =
        this.toNumber(this.stage.vars.positiony) +
        (this.toNumber(
          this.itemOf(this.stage.vars.scroolys, this.vars.yourreel - 1)
        ) +
          (this.toNumber(this.vars._1) + this.toNumber(this.vars.offsety)) *
            (this.size * -1.2));
      if (this.compare(179, this.y) < 0) {
        this.vars.offsety += 7;
      } else {
        if (this.compare(-179, this.y) > 0) {
          this.vars.offsety -= 7;
        } else {
          null;
        }
      }
      yield;
    }
  }

  *init() {
    this.effects.clear();
    this.stage.vars.checkingpos = 0;
    this.stage.vars.betperline = 240;
    this.stage.vars.spinning = 0;
    this.stage.vars.leftspins = 0;
    yield* this.showchips(1);
    yield* this.showchips(2);
    this.stage.vars.results = [];
    this.stage.vars.bets = [];
    this.stage.vars.bets.push(240);
    this.stage.vars.bets.push(480);
    this.stage.vars.bets.push(960);
    this.stage.vars.bets.push(1600);
    this.stage.vars.bets.push(2400);
    this.stage.vars.jackpotpoints = [];
    this.stage.vars.jackpotpoints.push(25);
    this.stage.vars.jackpotpoints.push(75);
    this.stage.vars.jackpotpoints.push(125);
    this.stage.vars.jackpotpoints.push(800);
    this.stage.vars.jackpotpoints.push(2750);
    this.stage.vars.jackpotpoints.push(6000);
    this.stage.vars.jackpotpoints.push(20000);
    this.stage.vars.jackpotpoints.push(80000);
    this.stage.vars.scroolys = [];
    this.stage.vars.scroolys.push(0);
    this.stage.vars.scroolys.push(0);
    this.stage.vars.scroolys.push(0);
    this.stage.vars.scroolys.push(0);
    this.stage.vars.scroolys.push(0);
    yield* this.clonereels(1, -1);
    yield* this.clonereels(2, -1);
    yield* this.clonereels(3, -1);
    yield* this.clonereels(4, -1);
    yield* this.clonereels(5, -1);
    this.vars.symbolscheckpos = [];
    this.vars.symbolscheckpos.push(22222);
    this.vars.symbolscheckpos.push(11111);
    this.vars.symbolscheckpos.push(33333);
    this.vars.symbolscheckpos.push(12321);
    this.vars.symbolscheckpos.push(32123);
    this.vars.symbolscheckpos.push(21112);
    this.vars.symbolscheckpos.push(23332);
    this.vars.symbolscheckpos.push(11233);
    this.vars.symbolscheckpos.push(33211);
    this.vars.symbolscheckpos.push(21232);
    this.vars.symbolscheckpos.push(23212);
    this.vars.symbolscheckpos.push(12221);
    this.vars.symbolscheckpos.push(32223);
    this.vars.symbolscheckpos.push(12121);
    this.vars.symbolscheckpos.push(32323);
    this.vars.symbolscheckpos.push(22122);
    this.vars.symbolscheckpos.push(22322);
    this.vars.symbolscheckpos.push(11311);
    this.vars.symbolscheckpos.push(33133);
    this.vars.symbolscheckpos.push(13331);
    this.vars.symbolscheckpos.push(31113);
    this.vars.symbolscheckpos.push(11211);
    this.vars.symbolscheckpos.push(33233);
    this.vars.symbolscheckpos.push(21212);
    this.vars.symbolscheckpos.push(23232);
  }

  *symbolscheck() {
    this.stage.vars.symbols = [];
    this.stage.vars.results = [];
    this.vars._2 = -1;
    this.vars.jackpot = 0;
    for (let i = 0; i < 3; i++) {
      this.vars._1 = 0;
      this.stage.vars.symbols.push("");
      for (let i = 0; i < 5; i++) {
        this.vars._1++;
        this.stage.vars.symbols.splice(
          "last",
          1,
          this.toString(
            this.itemOf(
              this.stage.vars.symbols,
              this.stage.vars.symbols.length - 1
            )
          ) +
            this.letterOf(
              this.itemOf(
                this.stage.vars.reel,
                (this.toNumber(
                  this.itemOf(this.stage.vars.scroolys, this.vars._1 - 1)
                ) /
                  (this.size * 1.2) +
                  this.toNumber(this.vars._2)) %
                  this.stage.vars.reel.length
              ),
              this.vars._1 - 1
            )
        );
        this.vars.jackpot +=
          this.toNumber(
            this.letterOf(
              this.itemOf(
                this.stage.vars.reel,
                (this.toNumber(
                  this.itemOf(this.stage.vars.scroolys, this.vars._1 - 1)
                ) /
                  (this.size * 1.2) +
                  this.toNumber(this.vars._2)) %
                  this.stage.vars.reel.length
              ),
              this.vars._1 - 1
            )
          ) *
          this.toNumber(
            this.compare(
              4,
              this.letterOf(
                this.itemOf(
                  this.stage.vars.reel,
                  (this.toNumber(
                    this.itemOf(this.stage.vars.scroolys, this.vars._1 - 1)
                  ) /
                    (this.size * 1.2) +
                    this.toNumber(this.vars._2)) %
                    this.stage.vars.reel.length
                ),
                this.vars._1 - 1
              )
            ) > 0
          );
        yield;
      }
      this.vars._2++;
      yield;
    }
    if (this.compare(2, this.vars.jackpot) < 0) {
      this.stage.vars.results.push(
        this.toNumber(this.stage.vars.betperline) *
          this.toNumber(
            this.itemOf(
              this.stage.vars.jackpotpoints,
              this.toNumber(this.vars.jackpot) - 3
            )
          )
      );
      this.stage.vars.results.push("---");
      this.stage.vars.results.push("JACKPOT");
    }
    this.vars._1 = 0;
    for (let i = 0; i < this.vars.symbolscheckpos.length; i++) {
      this.vars._1++;
      this.vars._2 = this.letterOf(
        this.itemOf(
          this.stage.vars.symbols,
          this.letterOf(
            this.itemOf(this.vars.symbolscheckpos, this.vars._1 - 1),
            0
          ) - 1
        ),
        0
      );
      this.vars._2 =
        this.toString(this.vars._2) +
        this.letterOf(
          this.itemOf(
            this.stage.vars.symbols,
            this.letterOf(
              this.itemOf(this.vars.symbolscheckpos, this.vars._1 - 1),
              1
            ) - 1
          ),
          1
        );
      this.vars._2 =
        this.toString(this.vars._2) +
        this.letterOf(
          this.itemOf(
            this.stage.vars.symbols,
            this.letterOf(
              this.itemOf(this.vars.symbolscheckpos, this.vars._1 - 1),
              2
            ) - 1
          ),
          2
        );
      this.vars._2 =
        this.toString(this.vars._2) +
        this.letterOf(
          this.itemOf(
            this.stage.vars.symbols,
            this.letterOf(
              this.itemOf(this.vars.symbolscheckpos, this.vars._1 - 1),
              3
            ) - 1
          ),
          3
        );
      this.vars._2 =
        this.toString(this.vars._2) +
        this.letterOf(
          this.itemOf(
            this.stage.vars.symbols,
            this.letterOf(
              this.itemOf(this.vars.symbolscheckpos, this.vars._1 - 1),
              4
            ) - 1
          ),
          4
        );
      this.vars._3 = this.letterOf(this.vars._2, 0);
      if (
        0 === this.toNumber(this.vars._3) ||
        (this.compare(3, this.vars._3) < 0 &&
          this.compare(
            12,
            this.toNumber("0x" + this.toString(this.vars._3)) + 0
          ) > 0)
      ) {
        this.vars._4 = 2;
        while (
          !(
            !(
              this.compare(
                this.vars._3,
                this.letterOf(this.vars._2, this.vars._4 - 1)
              ) === 0 ||
              this.toNumber(this.letterOf(this.vars._2, this.vars._4 - 1)) === 4
            ) || this.compare(5, this.vars._4) < 0
          )
        ) {
          this.vars._4++;
          yield;
        }
        if (this.compare(3, this.vars._4) < 0) {
          this.stage.vars.results.push("0x" + this.toString(this.vars._3));
          this.stage.vars.results.push(this.vars._4);
          this.stage.vars.results.push(this.vars._1);
        }
      }
      yield;
    }
    if (
      this.letterOf(this.itemOf(this.stage.vars.symbols, 0), 0) === "c" ||
      this.letterOf(this.itemOf(this.stage.vars.symbols, 1), 0) === "c" ||
      this.letterOf(this.itemOf(this.stage.vars.symbols, 2), 0) === "c"
    ) {
      if (
        this.letterOf(this.itemOf(this.stage.vars.symbols, 0), 2) === "c" ||
        this.letterOf(this.itemOf(this.stage.vars.symbols, 1), 2) === "c" ||
        this.letterOf(this.itemOf(this.stage.vars.symbols, 2), 2) === "c"
      ) {
        if (
          this.letterOf(this.itemOf(this.stage.vars.symbols, 0), 4) === "c" ||
          this.letterOf(this.itemOf(this.stage.vars.symbols, 1), 4) === "c" ||
          this.letterOf(this.itemOf(this.stage.vars.symbols, 2), 4) === "c"
        ) {
          this.stage.vars.results.push("---");
          this.stage.vars.results.push("---");
          this.stage.vars.results.push("RESPIN");
        }
      }
    }
  }

  *replacelist(_) {
    this.vars._3 = 0;
    for (let i = 0; i < this.stage.vars.scroolys.length; i++) {
      this.vars._3++;
      if (this.toNumber(_) === 1) {
        this.stage.vars.scroolys.splice(
          this.vars._3 - 1,
          1,
          this.toNumber(
            this.itemOf(this.stage.vars.scroolys, this.vars._3 - 1)
          ) + this.toNumber(this.vars._1)
        );
      } else {
        if (this.toNumber(_) === 2) {
          this.stage.vars.scroolys.splice(
            this.vars._3 - 1,
            1,
            this.toNumber(
              this.itemOf(this.stage.vars.scroolys, this.vars._3 - 1)
            ) +
              this.random(0, this.stage.vars.reel.length) * (this.size * 1.2)
          );
        } else {
          if (this.compare(this.vars._2, this.vars._3) === 0) {
            this.stage.vars.scroolys.splice(
              this.vars._3 - 1,
              1,
              this.toNumber(
                this.itemOf(this.stage.vars.scroolys, this.vars._3 - 1)
              ) + this.toNumber(this.vars._1)
            );
          } else {
            if (this.compare(this.vars._2, this.vars._3) < 0) {
              this.stage.vars.scroolys.splice(
                this.vars._3 - 1,
                1,
                this.toNumber(
                  this.itemOf(this.stage.vars.scroolys, this.vars._3 - 1)
                ) + -50
              );
            }
          }
        }
      }
      yield;
    }
  }

  *whenIReceiveHit() {
    this.vars._2 = 0;
    if (
      this.compare(
        this.vars.yourreel,
        this.itemOf(
          this.stage.vars.results,
          this.toNumber(this.stage.vars.checknum) + 1
        )
      ) < 0 &&
      this.compare(
        this.toNumber(this.stage.vars.positiony) + Math.round(this.y),
        this.toNumber(this.stage.vars.positiony) +
          (this.size * 2.4 +
            this.toNumber(
              this.letterOf(
                this.itemOf(
                  this.vars.symbolscheckpos,
                  this.itemOf(
                    this.stage.vars.results,
                    this.toNumber(this.stage.vars.checknum) + 2
                  ) - 1
                ),
                this.vars.yourreel - 1
              )
            ) *
              (this.size * -1.2))
      ) === 0
    ) {
      for (let i = 0; i < 3; i++) {
        this.vars._2 = this.toNumber(this.vars._2) + 10;
        for (let i = 0; i < 3; i++) {
          this.effects.brightness += 20;
          yield;
        }
        while (!!(this.compare(this.vars._2, this.stage.vars.checktime) > 0)) {
          yield;
        }
        this.vars._2 = this.toNumber(this.vars._2) + 10;
        for (let i = 0; i < 2; i++) {
          this.effects.brightness -= 30;
          yield;
        }
        while (!!(this.compare(this.vars._2, this.stage.vars.checktime) > 0)) {
          yield;
        }
        yield;
      }
    }
    if (
      this.toString(
        this.itemOf(
          this.stage.vars.results,
          this.toNumber(this.stage.vars.checknum) + 2
        )
      ) === "RESPIN" &&
      this.letterOf(
        this.itemOf(
          this.stage.vars.reel,
          (this.toNumber(this.vars._1) + this.toNumber(this.vars.offsety)) %
            this.stage.vars.reel.length
        ),
        this.vars.yourreel - 1
      ) === "c"
    ) {
      for (let i = 0; i < 5; i++) {
        this.vars._2 = this.toNumber(this.vars._2) + 10;
        for (let i = 0; i < 3; i++) {
          this.effects.brightness += 20;
          yield;
        }
        while (!!(this.compare(this.vars._2, this.stage.vars.checktime) > 0)) {
          yield;
        }
        this.vars._2 = this.toNumber(this.vars._2) + 10;
        for (let i = 0; i < 2; i++) {
          this.effects.brightness -= 30;
          yield;
        }
        while (!!(this.compare(this.vars._2, this.stage.vars.checktime) > 0)) {
          yield;
        }
        yield;
      }
    }
    if (
      this.compare(Math.abs(this.y), this.size * 2) < 0 &&
      this.toString(
        this.itemOf(
          this.stage.vars.results,
          this.toNumber(this.stage.vars.checknum) + 2
        )
      ) === "JACKPOT" &&
      this.compare(
        this.letterOf(
          this.itemOf(
            this.stage.vars.reel,
            (this.toNumber(this.vars._1) + this.toNumber(this.vars.offsety)) %
              this.stage.vars.reel.length
          ),
          this.vars.yourreel - 1
        ),
        0
      ) > 0 &&
      this.compare(
        this.letterOf(
          this.itemOf(
            this.stage.vars.reel,
            (this.toNumber(this.vars._1) + this.toNumber(this.vars.offsety)) %
              this.stage.vars.reel.length
          ),
          this.vars.yourreel - 1
        ),
        4
      ) < 0
    ) {
      for (let i = 0; i < 25; i++) {
        this.vars._2 = this.toNumber(this.vars._2) + 10;
        for (let i = 0; i < 3; i++) {
          this.effects.brightness += 20;
          yield;
        }
        while (!!(this.compare(this.vars._2, this.stage.vars.checktime) > 0)) {
          yield;
        }
        this.vars._2 = this.toNumber(this.vars._2) + 10;
        for (let i = 0; i < 2; i++) {
          this.effects.brightness -= 30;
          yield;
        }
        while (!!(this.compare(this.vars._2, this.stage.vars.checktime) > 0)) {
          yield;
        }
        yield;
      }
    }
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.size = 50;
  }

  *whenIReceiveGo() {
    yield* this.init();
    while (true) {
      while (!(this.toNumber(this.stage.vars.plessed) === 1)) {
        yield;
      }
      this.broadcast("pull");
      this.stage.vars.plessed = 0;
      this.stage.vars.chipsHidden +=
        this.toNumber(this.stage.vars.betperline) *
        this.vars.symbolscheckpos.length *
        -1;
      this.stage.vars.spinning = 1;
      yield* this.wait(0.5);
      this.stage.vars.leftspins = 1;
      while (!(this.toNumber(this.stage.vars.leftspins) === 0)) {
        this.stage.vars.leftspins--;
        yield* this.showchips(1);
        this.stage.vars.scrooly = 0;
        this.vars._1 = 0;
        for (let i = 0; i < 10; i++) {
          this.vars._1 += (this.size * -0.6) / 10;
          yield* this.replacelist(1);
          yield;
        }
        for (let i = 0; i < 10; i++) {
          yield* this.replacelist(1);
          yield;
        }
        this.vars._2 = 0;
        for (let i = 0; i < 5; i++) {
          this.vars._2++;
          this.vars._1 = this.size * -0.6;
          for (
            let i = 0;
            i < this.random(0, this.stage.vars.reel.length) * 2;
            i++
          ) {
            yield* this.replacelist(3);
            yield;
          }
          while (!(this.compare(this.vars._1, 0) > 0)) {
            this.vars._1 += (this.size * -0.6) / -5;
            yield* this.replacelist(3);
            yield;
          }
          this.vars._4 =
            Math.ceil(
              this.toNumber(
                this.itemOf(this.stage.vars.scroolys, this.vars._2 - 1)
              ) /
                (this.size * 1.2)
            ) *
            (this.size * 1.2);
          while (
            !!(
              this.compare(
                this.vars._4,
                this.toNumber(
                  this.itemOf(this.stage.vars.scroolys, this.vars._2 - 1)
                ) + this.toNumber(this.vars._1)
              ) > 0
            )
          ) {
            this.vars._1 += (this.size * -0.6) / -5;
            yield* this.replacelist(3);
            yield;
          }
          this.broadcast("stop");
          this.stage.vars.scroolys.splice(this.vars._2 - 1, 1, this.vars._4);
          yield;
        }
        yield* this.symbolscheck();
        this.stage.vars.checknum = 0;
        for (let i = 0; i < this.stage.vars.results.length / 3; i++) {
          this.stage.vars.checkingpos = this.itemOf(
            this.stage.vars.results,
            this.toNumber(this.stage.vars.checknum) + 2
          );
          this.broadcast("HIT!");
          this.stage.vars.checktime = 0;
          if (
            this.toString(
              this.itemOf(
                this.stage.vars.results,
                this.toNumber(this.stage.vars.checknum) + 2
              )
            ) === "RESPIN"
          ) {
            this.stage.vars.leftspins = 5;
            for (let i = 0; i < 100; i++) {
              this.stage.vars.checktime++;
              yield;
            }
          } else {
            if (
              this.toString(
                this.itemOf(
                  this.stage.vars.results,
                  this.toNumber(this.stage.vars.checknum) + 2
                )
              ) === "JACKPOT"
            ) {
              for (let i = 0; i < 500; i++) {
                this.stage.vars.checktime++;
                this.stage.vars.wonchipsHidden +=
                  this.toNumber(
                    this.itemOf(
                      this.stage.vars.results,
                      this.toNumber(this.stage.vars.checknum)
                    )
                  ) / 500;
                yield* this.showchips(2);
                yield;
              }
            } else {
              for (let i = 0; i < 60; i++) {
                this.stage.vars.checktime++;
                this.stage.vars.wonchipsHidden +=
                  this.toNumber(
                    this.itemOf(
                      this.stage.vars.hitpoints,
                      this.toNumber(
                        this.itemOf(
                          this.stage.vars.results,
                          this.toNumber(this.stage.vars.checknum)
                        )
                      ) *
                        3 +
                        (this.toNumber(
                          this.itemOf(
                            this.stage.vars.results,
                            this.toNumber(this.stage.vars.checknum) + 1
                          )
                        ) -
                          3) -
                        1
                    )
                  ) / 60;
                yield* this.showchips(2);
                yield;
              }
            }
          }
          this.stage.vars.checknum += 3;
          yield;
        }
        this.stage.vars.checkingpos = 0;
        this.stage.vars.results = [];
        yield;
      }
      if (this.compare(this.stage.vars.wonchipsHidden, 0) > 0) {
        this.broadcast("WonSound");
        for (let i = 0; i < 50; i++) {
          this.stage.vars.chipsHidden +=
            this.toNumber(this.stage.vars.wonchipsHidden) / 50;
          yield* this.showchips(1);
          yield;
        }
      }
      this.stage.vars.spinning = 0;
      this.stage.vars.wonchipsHidden = 0;
      yield;
    }
  }

  *showchips(num) {
    if (this.toNumber(num) === 1) {
      this.stage.vars.chips = "";
      this.vars._1 = Math.round(
        this.toNumber(this.stage.vars.chipsHidden)
      ).length;
      this.vars._2 = 0;
      for (
        let i = 0;
        i < Math.round(this.toNumber(this.stage.vars.chipsHidden)).length;
        i++
      ) {
        this.stage.vars.chips =
          this.letterOf(
            Math.round(this.toNumber(this.stage.vars.chipsHidden)),
            this.vars._1 - 1
          ) + this.toString(this.stage.vars.chips);
        this.vars._1--;
        this.vars._2++;
        if (
          this.toNumber(this.vars._2) % 3 === 0 &&
          this.compare(this.vars._1, 0) > 0
        ) {
          this.stage.vars.chips = "," + this.toString(this.stage.vars.chips);
        }
        yield;
      }
    } else {
      this.stage.vars.wonchips = "";
      this.vars._1 = Math.round(
        this.toNumber(this.stage.vars.wonchipsHidden)
      ).length;
      this.vars._2 = 0;
      for (
        let i = 0;
        i < Math.round(this.toNumber(this.stage.vars.wonchipsHidden)).length;
        i++
      ) {
        this.stage.vars.wonchips =
          this.letterOf(
            Math.round(this.toNumber(this.stage.vars.wonchipsHidden)),
            this.vars._1 - 1
          ) + this.toString(this.stage.vars.wonchips);
        this.vars._1--;
        this.vars._2++;
        if (
          this.toNumber(this.vars._2) % 3 === 0 &&
          this.compare(this.vars._1, 0) > 0
        ) {
          this.stage.vars.wonchips =
            "," + this.toString(this.stage.vars.wonchips);
        }
        yield;
      }
    }
  }
}
