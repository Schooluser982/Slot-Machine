/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Telop extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("JACKPOT", "./Telop/costumes/JACKPOT.svg", {
        x: 182,
        y: 152,
      }),
      new Costume("RESPIN", "./Telop/costumes/RESPIN.svg", { x: 133, y: 118 }),
    ];

    this.sounds = [new Sound("ポップ", "./Telop/sounds/ポップ.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "HIT!" }, this.whenIReceiveHit),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveHit() {
    if (
      this.toString(
        this.itemOf(
          this.stage.vars.results,
          this.toNumber(this.stage.vars.checknum) + 2
        )
      ) === "RESPIN" ||
      this.toString(
        this.itemOf(
          this.stage.vars.results,
          this.toNumber(this.stage.vars.checknum) + 2
        )
      ) === "JACKPOT"
    ) {
      this.visible = true;
      this.moveAhead();
      this.effects.ghost = 100;
      this.y = 240;
      if (
        this.toString(
          this.itemOf(
            this.stage.vars.results,
            this.toNumber(this.stage.vars.checknum) + 2
          )
        ) === "RESPIN"
      ) {
        this.costume = "RESPIN";
        for (let i = 0; i < 30; i++) {
          this.y += (0 - this.y) / 10;
          this.effects.ghost -= 5;
          this.moveAhead();
          yield;
        }
      } else {
        this.costume = "JACKPOT";
        for (let i = 0; i < 200; i++) {
          this.y += (0 - this.y) / 10;
          this.effects.ghost -= 5;
          this.moveAhead();
          yield;
        }
      }
      for (let i = 0; i < 50; i++) {
        this.y += (0 - this.y) / 10;
        this.effects.ghost += 2;
        this.moveAhead();
        yield;
      }
      this.visible = false;
    }
  }
}
