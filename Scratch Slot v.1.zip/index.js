import {
  Project,
  Sprite,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import Reels from "./Reels/Reels.js";
import Edge from "./Edge/Edge.js";
import Chips from "./Chips/Chips.js";
import Nummoney from "./Nummoney/Nummoney.js";
import Bet from "./Bet/Bet.js";
import Paytable from "./Paytable/Paytable.js";
import Spin from "./Spin/Spin.js";
import Cloudlist from "./Cloudlist/Cloudlist.js";
import Letters from "./Letters/Letters.js";
import Telop from "./Telop/Telop.js";
import Se from "./Se/Se.js";
import Bgm from "./Bgm/Bgm.js";

const stage = new Stage({ costumeNumber: 1 });

const sprites = {
  Reels: new Reels({
    x: -240,
    y: -188,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 13,
    size: 50,
    visible: false,
    layerOrder: 1,
  }),
  Edge: new Edge({
    x: 0,
    y: 0,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 10,
  }),
  Chips: new Chips({
    x: 215,
    y: -108.25,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 80,
    visible: false,
    layerOrder: 2,
  }),
  Nummoney: new Nummoney({
    x: 13,
    y: -145,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 125,
    visible: false,
    layerOrder: 4,
  }),
  Bet: new Bet({
    x: 180,
    y: -145,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 12,
  }),
  Paytable: new Paytable({
    x: 80,
    y: -145,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 4,
    size: 100,
    visible: false,
    layerOrder: 3,
  }),
  Spin: new Spin({
    x: -45,
    y: -145,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 11,
  }),
  Cloudlist: new Cloudlist({
    x: 0,
    y: 0,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 54,
    size: 100,
    visible: false,
    layerOrder: 8,
  }),
  Letters: new Letters({
    x: 19,
    y: -115,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 53,
    size: 100,
    visible: false,
    layerOrder: 5,
  }),
  Telop: new Telop({
    x: 0,
    y: 0.052433880126814165,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 2,
    size: 100,
    visible: false,
    layerOrder: 9,
  }),
  Se: new Se({
    x: 93,
    y: -2,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 6,
  }),
  Bgm: new Bgm({
    x: -55,
    y: -50,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 7,
  }),
};

const project = new Project(stage, sprites, {
  frameRate: 30, // Set to 60 to make your project run faster
});
export default project;
