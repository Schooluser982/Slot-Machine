/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Letters extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("uA", "./Letters/costumes/uA.svg", { x: 2, y: 16 }),
      new Costume("uB", "./Letters/costumes/uB.svg", { x: 4, y: 16 }),
      new Costume("uC", "./Letters/costumes/uC.svg", { x: 4, y: 16 }),
      new Costume("uD", "./Letters/costumes/uD.svg", { x: 4, y: 16 }),
      new Costume("uE", "./Letters/costumes/uE.svg", { x: 4, y: 16 }),
      new Costume("uF", "./Letters/costumes/uF.svg", { x: 4, y: 16 }),
      new Costume("uG", "./Letters/costumes/uG.svg", { x: 4, y: 16 }),
      new Costume("uH", "./Letters/costumes/uH.svg", { x: 4, y: 16 }),
      new Costume("uI", "./Letters/costumes/uI.svg", { x: 4, y: 16 }),
      new Costume("uJ", "./Letters/costumes/uJ.svg", { x: 4, y: 16 }),
      new Costume("uK", "./Letters/costumes/uK.svg", { x: 4, y: 16 }),
      new Costume("uL", "./Letters/costumes/uL.svg", { x: 4, y: 16 }),
      new Costume("uM", "./Letters/costumes/uM.svg", { x: 3, y: 16 }),
      new Costume("uN", "./Letters/costumes/uN.svg", { x: 3, y: 16 }),
      new Costume("uO", "./Letters/costumes/uO.svg", { x: 3, y: 16 }),
      new Costume("uP", "./Letters/costumes/uP.svg", { x: 4, y: 16 }),
      new Costume("uQ", "./Letters/costumes/uQ.svg", { x: 3, y: 16 }),
      new Costume("uR", "./Letters/costumes/uR.svg", { x: 4, y: 16 }),
      new Costume("uS", "./Letters/costumes/uS.svg", { x: 4, y: 16 }),
      new Costume("uT", "./Letters/costumes/uT.svg", { x: 3, y: 16 }),
      new Costume("uU", "./Letters/costumes/uU.svg", { x: 3, y: 16 }),
      new Costume("uV", "./Letters/costumes/uV.svg", { x: 2, y: 16 }),
      new Costume("uW", "./Letters/costumes/uW.svg", { x: 2, y: 16 }),
      new Costume("uX", "./Letters/costumes/uX.svg", { x: 3, y: 16 }),
      new Costume("uY", "./Letters/costumes/uY.svg", { x: 3, y: 16 }),
      new Costume("uZ", "./Letters/costumes/uZ.svg", { x: 3, y: 16 }),
      new Costume("a", "./Letters/costumes/a.svg", { x: 4, y: 16 }),
      new Costume("b", "./Letters/costumes/b.svg", { x: 4, y: 16 }),
      new Costume("c", "./Letters/costumes/c.svg", { x: 3, y: 16 }),
      new Costume("d", "./Letters/costumes/d.svg", { x: 3, y: 16 }),
      new Costume("e", "./Letters/costumes/e.svg", { x: 3, y: 16 }),
      new Costume("f", "./Letters/costumes/f.svg", { x: 3, y: 16 }),
      new Costume("g", "./Letters/costumes/g.svg", { x: 4, y: 16 }),
      new Costume("h", "./Letters/costumes/h.svg", { x: 3, y: 16 }),
      new Costume("i", "./Letters/costumes/i.svg", { x: 3, y: 16 }),
      new Costume("j", "./Letters/costumes/j.svg", { x: 3, y: 16 }),
      new Costume("k", "./Letters/costumes/k.svg", { x: 3, y: 16 }),
      new Costume("l", "./Letters/costumes/l.svg", { x: 3, y: 16 }),
      new Costume("m", "./Letters/costumes/m.svg", { x: 3, y: 16 }),
      new Costume("n", "./Letters/costumes/n.svg", { x: 3, y: 16 }),
      new Costume("o", "./Letters/costumes/o.svg", { x: 3, y: 16 }),
      new Costume("p", "./Letters/costumes/p.svg", { x: 3, y: 16 }),
      new Costume("q", "./Letters/costumes/q.svg", { x: 3, y: 16 }),
      new Costume("r", "./Letters/costumes/r.svg", { x: 3, y: 16 }),
      new Costume("s", "./Letters/costumes/s.svg", { x: 4, y: 16 }),
      new Costume("t", "./Letters/costumes/t.svg", { x: 3, y: 16 }),
      new Costume("u", "./Letters/costumes/u.svg", { x: 3, y: 16 }),
      new Costume("v", "./Letters/costumes/v.svg", { x: 3, y: 16 }),
      new Costume("w", "./Letters/costumes/w.svg", { x: 3, y: 16 }),
      new Costume("x", "./Letters/costumes/x.svg", { x: 3, y: 16 }),
      new Costume("y", "./Letters/costumes/y.svg", { x: 3, y: 16 }),
      new Costume("z", "./Letters/costumes/z.svg", { x: 3, y: 16 }),
      new Costume("0", "./Letters/costumes/0.svg", { x: 4, y: 16 }),
      new Costume("1", "./Letters/costumes/1.svg", { x: 4, y: 16 }),
      new Costume("2", "./Letters/costumes/2.svg", { x: 4, y: 16 }),
      new Costume("3", "./Letters/costumes/3.svg", { x: 4, y: 16 }),
      new Costume("4", "./Letters/costumes/4.svg", { x: 3, y: 16 }),
      new Costume("5", "./Letters/costumes/5.svg", { x: 4, y: 16 }),
      new Costume("6", "./Letters/costumes/6.svg", { x: 4, y: 16 }),
      new Costume("7", "./Letters/costumes/7.svg", { x: 4, y: 16 }),
      new Costume("8", "./Letters/costumes/8.svg", { x: 4, y: 16 }),
      new Costume("9", "./Letters/costumes/9.svg", { x: 4, y: 16 }),
      new Costume("-", "./Letters/costumes/-.svg", { x: 4, y: 16 }),
      new Costume("_", "./Letters/costumes/_.svg", { x: 2, y: 16 }),
      new Costume(",", "./Letters/costumes/,.svg", { x: 4, y: 15 }),
      new Costume(":", "./Letters/costumes/:.svg", { x: 4, y: 15 }),
      new Costume(" ", "./Letters/costumes/ .svg", { x: 240, y: 180 }),
    ];

    this.sounds = [new Sound("ポップ", "./Letters/sounds/ポップ.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "WriteRanking" },
        this.whenIReceiveWriteranking
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
    ];

    this.vars.write1 = 22;
    this.vars.showchips2 = 0;
    this.vars.showchips1 = 7;
    this.vars.showchipsRetrun = "1,288,580";
    this.vars._1 = 16;
    this.vars._2 = 0;
    this.vars._3 = "@assc";
    this.vars.bgmlag = 0.34499999999999886;
    this.vars.writeLetterspace = [
      23, 21, 23, 25, 21, 21, 23, 25, 14, 14, 23, 21, 28, 25, 25, 21, 25, 22,
      21, 22, 24, 21, 30, 23, 22, 21, 18, 20, 17, 19, 18, 15, 19, 21, 14, 14,
      19, 14, 28, 21, 19, 20, 19, 17, 17, 15, 21, 19, 25, 19, 19, 18, 21, 16,
      19, 18, 19, 18, 19, 18, 19, 19, 17, 21, 13, 13, 13,
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveWriteranking() {
    this.vars.bgmlag = this.timer;
    yield* this.broadcastAndWait("getcloud");
    yield* this.makeRanking(8);
    this.vars.bgmlag = this.timer - this.toNumber(this.vars.bgmlag);
    this.stage.vars.bgmtime += this.toNumber(this.vars.bgmlag);
  }

  *startAsClone() {
    this.visible = true;
    while (!!(this.toNumber(this.stage.vars.paytablepage) === 5)) {
      this.moveAhead();
      yield;
    }
    this.deleteThisClone();
  }

  *showchips(num) {
    this.vars.showchips1 = 0;
    this.vars.showchips2 = Math.round(this.toNumber(num)).length;
    this.vars.showchipsRetrun = "";
    for (let i = 0; i < this.toNumber(this.vars.showchips2); i++) {
      this.vars.showchipsRetrun =
        this.letterOf(
          Math.round(this.toNumber(num)),
          this.vars.showchips2 - 1
        ) + this.toString(this.vars.showchipsRetrun);
      this.vars.showchips2--;
      this.vars.showchips1++;
      if (
        this.toNumber(this.vars.showchips1) % 3 === 0 &&
        this.compare(this.vars.showchips2, 0) > 0
      ) {
        this.vars.showchipsRetrun =
          "," + this.toString(this.vars.showchipsRetrun);
      }
      yield;
    }
  }

  *writeAtXYSizeStartAt(string, x, y, size, start) {
    this.size = this.toNumber(size);
    this.vars.write1 = start;
    this.goto(this.toNumber(x), this.toNumber(y));
    for (let i = 0; i < string.length - this.toNumber(start); i++) {
      this.vars.write1++;
      this.costume = this.letterOf(string, this.vars.write1 - 1);
      this.costume = "u" + this.letterOf(string, this.vars.write1 - 1);
      if (!(this.toNumber(this.letterOf(string, this.vars.write1 - 1)) === 0)) {
        this.createClone();
      }
      this.x +=
        (this.toNumber(
          this.itemOf(this.vars.writeLetterspace, this.costumeNumber - 1)
        ) -
          7) *
        (this.toNumber(size) / 100);
      yield;
    }
  }

  *makeRanking(num) {
    this.stage.vars.ranking = [];
    this.vars._1 = 0;
    for (let i = 0; i < this.stage.vars.cloudlist.length / 4; i++) {
      if (
        !this.arrayIncludes(
          this.stage.vars.ranking,
          this.itemOf(this.stage.vars.cloudlist, this.toNumber(this.vars._1))
        )
      ) {
        this.stage.vars.ranking.push(
          this.itemOf(this.stage.vars.cloudlist, this.toNumber(this.vars._1))
        );
        this.stage.vars.ranking.push(
          this.itemOf(
            this.stage.vars.cloudlist,
            this.toNumber(this.vars._1) + 1
          )
        );
      }
      this.vars._1 += 4;
      yield;
    }
    this.vars._2 = this.stage.vars.ranking.length / 2;
    for (let i = 0; i < this.stage.vars.ranking.length / 2; i++) {
      this.vars._1 = 0;
      for (let i = 0; i < this.toNumber(this.vars._2); i++) {
        if (
          this.compare(
            this.itemOf(
              this.stage.vars.ranking,
              this.toNumber(this.vars._1) + 1
            ),
            this.itemOf(
              this.stage.vars.ranking,
              this.toNumber(this.vars._1) + 3
            )
          ) < 0
        ) {
          this.vars._3 = this.itemOf(
            this.stage.vars.ranking,
            this.toNumber(this.vars._1) + 1
          );
          this.stage.vars.ranking.splice(
            this.toNumber(this.vars._1) + 1,
            1,
            this.itemOf(
              this.stage.vars.ranking,
              this.toNumber(this.vars._1) + 3
            )
          );
          this.stage.vars.ranking.splice(
            this.toNumber(this.vars._1) + 3,
            1,
            this.vars._3
          );
          this.vars._3 = this.itemOf(
            this.stage.vars.ranking,
            this.toNumber(this.vars._1)
          );
          this.stage.vars.ranking.splice(
            this.toNumber(this.vars._1),
            1,
            this.itemOf(
              this.stage.vars.ranking,
              this.toNumber(this.vars._1) + 2
            )
          );
          this.stage.vars.ranking.splice(
            this.toNumber(this.vars._1) + 2,
            1,
            this.vars._3
          );
        }
        this.vars._1 += 2;
        yield;
      }
      this.vars._2--;
      yield;
    }
    for (
      let i = 0;
      i < this.stage.vars.ranking.length / 2 - this.toNumber(num);
      i++
    ) {
      this.stage.vars.ranking.splice(this.toNumber(num) * 2, 1);
      this.stage.vars.ranking.splice(this.toNumber(num) * 2, 1);
      yield;
    }
    this.vars._1 = 0;
    this.y = 105;
    for (let i = 0; i < this.stage.vars.ranking.length / 2; i++) {
      yield* this.showchips(
        this.itemOf(this.stage.vars.ranking, this.toNumber(this.vars._1) + 1)
      );
      yield* this.writeAtXYSizeStartAt(
        this.toString(
          this.itemOf(this.stage.vars.ranking, this.toNumber(this.vars._1))
        ) +
          " : " +
          this.toString(this.vars.showchipsRetrun),
        -195,
        this.y,
        100,
        1
      );
      this.y -= 27.5;
      this.vars._1 += 2;
      yield;
    }
  }
}
