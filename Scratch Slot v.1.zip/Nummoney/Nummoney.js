/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Nummoney extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("0", "./Nummoney/costumes/0.svg", { x: 8, y: 15 }),
      new Costume("1", "./Nummoney/costumes/1.svg", { x: 8, y: 15 }),
      new Costume("2", "./Nummoney/costumes/2.svg", { x: 8, y: 15 }),
      new Costume("3", "./Nummoney/costumes/3.svg", { x: 8, y: 15 }),
      new Costume("4", "./Nummoney/costumes/4.svg", { x: 8, y: 15 }),
      new Costume("5", "./Nummoney/costumes/5.svg", { x: 8, y: 15 }),
      new Costume("6", "./Nummoney/costumes/6.svg", { x: 8, y: 15 }),
      new Costume("7", "./Nummoney/costumes/7.svg", { x: 8, y: 15 }),
      new Costume("8", "./Nummoney/costumes/8.svg", { x: 8, y: 15 }),
      new Costume("9", "./Nummoney/costumes/9.svg", { x: 8, y: 15 }),
      new Costume(",", "./Nummoney/costumes/,.svg", { x: 6, y: 15 }),
      new Costume("_", "./Nummoney/costumes/_.svg", { x: 240, y: 180 }),
      new Costume("money", "./Nummoney/costumes/money.svg", { x: 11, y: 12 }),
      new Costume("+", "./Nummoney/costumes/+.svg", { x: 9, y: 17 }),
      new Costume("spins left", "./Nummoney/costumes/spins left.svg", {
        x: 21,
        y: 17,
      }),
      new Costume("-", "./Nummoney/costumes/-.svg", { x: 9, y: 17 }),
      new Costume(":", "./Nummoney/costumes/:.svg", { x: 6, y: 17 }),
    ];

    this.sounds = [new Sound("ポップ", "./Nummoney/sounds/ポップ.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.BROADCAST, { name: "GO" }, this.whenIReceiveGo),
    ];

    this.vars._1 = 6;
    this.vars._2 = 6;
  }

  *init() {
    this.vars._2 = 0;
    this.goto(-225, 162.5);
    this.costume = "money";
    this.createClone();
    this.x += 22.5;
    this.vars._2 = 1;
    this.vars._1 = 15;
    this.costume = 0;
    for (let i = 0; i < 4; i++) {
      for (let i = 0; i < 3; i++) {
        this.createClone();
        this.x += 15;
        this.vars._1--;
        yield;
      }
      if (this.compare(this.vars._1, 0) > 0) {
        this.x -= 2.5;
        this.createClone();
        this.x += 10;
        this.vars._1--;
      }
      yield;
    }
    this.vars._2 = 3;
    this.goto(15, 162.5);
    this.costume = "+";
    this.createClone();
    this.x += 22.5;
    this.vars._2 = 2;
    this.vars._1 = 15;
    this.costume = 0;
    for (let i = 0; i < 4; i++) {
      for (let i = 0; i < 3; i++) {
        this.createClone();
        this.x += 15;
        this.vars._1--;
        yield;
      }
      if (this.compare(this.vars._1, 0) > 0) {
        this.x -= 2.5;
        this.createClone();
        this.x += 10;
        this.vars._1--;
      }
      yield;
    }
    this.size = 200;
    this.vars._2 = 4;
    this.goto(-215, -145);
    this.costume = 0;
    this.createClone();
    this.vars._2 = 5;
    this.goto(-215, -145);
    this.costume = "spins left";
    this.createClone();
    this.vars._1 = 0;
    this.size = 125;
    this.goto(-95, -145);
    for (let i = 0; i < 3; i++) {
      this.vars._2 = 6;
      this.costume = 0;
      for (let i = 0; i < 2; i++) {
        this.vars._1++;
        this.createClone();
        this.x += 16;
        yield;
      }
      if (this.compare(this.vars._1, 6) < 0) {
        this.vars._2 = 7;
        this.x -= 5;
        this.costume = ":";
        this.createClone();
        this.x += 11;
      }
      yield;
    }
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.size = 120;
  }

  *startAsClone() {
    if (this.toNumber(this.vars._2) === 1) {
      this.visible = true;
      this.moveAhead();
      while (true) {
        if (
          this.toNumber(
            this.letterOf(
              this.stage.vars.chips,
              this.stage.vars.chips.length - this.toNumber(this.vars._1)
            )
          ) === 0
        ) {
          this.costume = "_";
        } else {
          this.costume = this.letterOf(
            this.stage.vars.chips,
            this.stage.vars.chips.length - this.toNumber(this.vars._1)
          );
        }
        yield;
      }
    } else {
      if (this.toNumber(this.vars._2) === 2) {
        while (true) {
          if (this.compare(0, this.stage.vars.wonchipsHidden) < 0) {
            this.visible = true;
            this.moveAhead();
            if (
              this.toNumber(
                this.letterOf(
                  this.stage.vars.wonchips,
                  this.stage.vars.wonchips.length - this.toNumber(this.vars._1)
                )
              ) === 0
            ) {
              this.costume = "_";
            } else {
              this.costume = this.letterOf(
                this.stage.vars.wonchips,
                this.stage.vars.wonchips.length - this.toNumber(this.vars._1)
              );
            }
          } else {
            this.visible = false;
          }
          yield;
        }
      } else {
        if (this.toNumber(this.vars._2) === 3) {
          while (true) {
            if (this.compare(0, this.stage.vars.wonchipsHidden) < 0) {
              this.visible = true;
              this.moveAhead();
            } else {
              this.visible = false;
            }
            yield;
          }
        } else {
          if (this.toNumber(this.vars._2) === 4) {
            this.visible = false;
            this.effects.ghost = 100;
            while (true) {
              if (this.compare(0, this.stage.vars.leftspins) < 0) {
                this.costume = "" + this.toString(this.stage.vars.leftspins);
                this.visible = true;
                this.moveAhead();
                this.effects.ghost -= 10;
              } else {
                this.effects.ghost += 10;
              }
              yield;
            }
          } else {
            if (this.toNumber(this.vars._2) === 5) {
              this.visible = false;
              this.effects.ghost = 100;
              while (true) {
                if (this.compare(0, this.stage.vars.leftspins) < 0) {
                  this.visible = true;
                  this.moveAhead();
                  this.moveBehind(1);
                  this.effects.ghost -= 10;
                } else {
                  this.effects.ghost += 10;
                }
                yield;
              }
            } else {
              if (this.toNumber(this.vars._2) === 6) {
                while (true) {
                  if (this.compare(this.stage.vars.chipsHidden, 0) > 0) {
                    this.visible = false;
                  } else {
                    this.visible = true;
                    this.moveAhead();
                    if (this.compare(this.vars._1, 3) < 0) {
                      this.vars._2 = 23 - new Date().getHours();
                    } else {
                      if (this.compare(this.vars._1, 5) < 0) {
                        this.vars._2 = 59 - new Date().getMinutes();
                      } else {
                        this.vars._2 = 59 - new Date().getSeconds();
                      }
                    }
                    this.vars._2 =
                      this.letterOf(0, this.vars._2.length - 1) +
                      this.toString(this.vars._2);
                    this.costume = this.letterOf(
                      this.vars._2,
                      1 - (this.toNumber(this.vars._1) % 2)
                    );
                  }
                  yield;
                }
              } else {
                if (this.toNumber(this.vars._2) === 7) {
                  while (true) {
                    if (this.compare(this.stage.vars.chipsHidden, 0) > 0) {
                      this.visible = false;
                    } else {
                      this.visible = true;
                      this.moveAhead();
                    }
                    yield;
                  }
                } else {
                  this.visible = true;
                  this.moveAhead();
                }
              }
            }
          }
        }
      }
    }
  }

  *whenIReceiveGo() {
    yield* this.init();
  }
}
