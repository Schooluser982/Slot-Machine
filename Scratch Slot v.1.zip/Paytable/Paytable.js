/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Paytable extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("PAYTABLE ", "./Paytable/costumes/PAYTABLE .svg", {
        x: 43,
        y: 21,
      }),
      new Costume("NEXT", "./Paytable/costumes/NEXT.svg", { x: 43, y: 21 }),
      new Costume("BACK", "./Paytable/costumes/BACK.svg", { x: 43, y: 21 }),
      new Costume("PT-1", "./Paytable/costumes/PT-1.svg", { x: 208, y: 173 }),
      new Costume("PT-2", "./Paytable/costumes/PT-2.svg", { x: 208, y: 173 }),
      new Costume("PT-3", "./Paytable/costumes/PT-3.svg", { x: 208, y: 173 }),
      new Costume("PT-4", "./Paytable/costumes/PT-4.svg", { x: 208, y: 173 }),
      new Costume("PT-5", "./Paytable/costumes/PT-5.svg", { x: 208, y: 173 }),
    ];

    this.sounds = [
      new Sound(
        "se_maoudamashii_se_pc01.mp3",
        "./Paytable/sounds/se_maoudamashii_se_pc01.mp3.wav"
      ),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.BROADCAST, { name: "GO" }, this.whenIReceiveGo),
    ];

    this.vars._1 = 2;
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *startAsClone() {
    if (this.toNumber(this.vars._1) === 1) {
      this.goto(80, -145);
      this.visible = true;
      this.moveAhead();
      while (true) {
        if (this.toNumber(this.stage.vars.paytablepage) === 0) {
          this.costume = "PAYTABLE ";
        } else {
          if (this.toNumber(this.stage.vars.paytablepage) === 5) {
            this.costume = "BACK";
          } else {
            this.costume = "NEXT";
          }
        }
        if (this.toNumber(this.stage.vars.spinning) === 0) {
          if (this.touching("mouse")) {
            if (this.mouse.down) {
              yield* this.startSound("se_maoudamashii_se_pc01.mp3");
              this.stage.vars.paytablepage =
                (this.toNumber(this.stage.vars.paytablepage) + 1) % 6;
              this.effects.brightness = 10;
              if (this.toNumber(this.stage.vars.paytablepage) === 0) {
                this.costume = "PAYTABLE ";
              } else {
                if (this.toNumber(this.stage.vars.paytablepage) === 5) {
                  this.broadcast("WriteRanking");
                  this.costume = "BACK";
                } else {
                  this.costume = "NEXT";
                }
              }
              while (!!this.mouse.down) {
                yield;
              }
            } else {
              this.effects.brightness = 25;
            }
          } else {
            this.effects.brightness = 0;
          }
        } else {
          this.effects.brightness = -25;
        }
        yield;
      }
    } else {
      if (this.toNumber(this.vars._1) === 2) {
        this.goto(0, 0);
        while (true) {
          this.costume = "PT-" + this.toString(this.stage.vars.paytablepage);
          if (this.compare(0, this.stage.vars.paytablepage) < 0) {
            this.visible = true;
            this.moveAhead();
          } else {
            this.visible = false;
          }
          yield;
        }
      } else {
        null;
      }
    }
  }

  *whenIReceiveGo() {
    this.stage.vars.paytablepage = 0;
    this.vars._1 = 1;
    this.costume = "PAYTABLE ";
    this.createClone();
    this.vars._1 = 2;
    this.costume = "PT-1";
    this.createClone();
  }
}
