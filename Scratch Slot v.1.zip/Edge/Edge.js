/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Edge extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("edge", "./Edge/costumes/edge.svg", { x: 263, y: 298 }),
      new Costume("white", "./Edge/costumes/white.svg", { x: 241, y: 180 }),
    ];

    this.sounds = [new Sound("ポップ", "./Edge/sounds/ポップ.wav")];

    this.triggers = [
      new Trigger(Trigger.BROADCAST, { name: "GO" }, this.whenIReceiveGo),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
    ];
  }

  *whenIReceiveGo() {
    this.createClone();
    this.costume = "edge";
    this.stage.vars.positiony = 0;
    this.visible = true;
    this.moveAhead();
    this.goto(0, this.toNumber(this.stage.vars.positiony));
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *startAsClone() {
    this.costume = "white";
    this.moveBehind(999);
    this.visible = true;
  }
}
