/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Spin extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("SPIN!", "./Spin/costumes/SPIN!.svg", { x: 72, y: 21 }),
    ];

    this.sounds = [
      new Sound(
        "se_maoudamashii_se_pc01.mp3",
        "./Spin/sounds/se_maoudamashii_se_pc01.mp3.wav"
      ),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "GO" }, this.whenIReceiveGo),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveGo() {
    this.effects.clear();
    this.goto(-45, -145);
    this.visible = true;
    while (true) {
      this.moveAhead();
      if (
        this.toNumber(this.stage.vars.spinning) === 0 &&
        this.compare(this.stage.vars.chipsHidden, 0) > 0
      ) {
        if (this.touching("mouse")) {
          if (
            this.mouse.down &&
            this.toNumber(this.stage.vars.paytablepage) === 0
          ) {
            this.effects.brightness = 10;
            this.stage.vars.plessed = 1;
            while (!(this.toNumber(this.stage.vars.spinning) === 1)) {
              yield;
            }
            this.stage.vars.plessed = 0;
          } else {
            this.effects.brightness = 25;
          }
        } else {
          this.effects.brightness = 0;
        }
      } else {
        this.effects.brightness = -30;
      }
      yield;
    }
  }
}
