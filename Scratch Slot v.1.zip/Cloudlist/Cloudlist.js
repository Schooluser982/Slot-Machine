/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Cloudlist extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("CL by MMGISS", "./Cloudlist/costumes/CL by MMGISS.svg", {
        x: 93,
        y: 48,
      }),
      new Costume("a", "./Cloudlist/costumes/a.svg", { x: 0, y: 0 }),
      new Costume("b", "./Cloudlist/costumes/b.svg", { x: 0, y: 0 }),
      new Costume("c", "./Cloudlist/costumes/c.svg", { x: 0, y: 0 }),
      new Costume("d", "./Cloudlist/costumes/d.svg", { x: 0, y: 0 }),
      new Costume("e", "./Cloudlist/costumes/e.svg", { x: 0, y: 0 }),
      new Costume("f", "./Cloudlist/costumes/f.svg", { x: 0, y: 0 }),
      new Costume("g", "./Cloudlist/costumes/g.svg", { x: 0, y: 0 }),
      new Costume("h", "./Cloudlist/costumes/h.svg", { x: 0, y: 0 }),
      new Costume("i", "./Cloudlist/costumes/i.svg", { x: 0, y: 0 }),
      new Costume("j", "./Cloudlist/costumes/j.svg", { x: 0, y: 0 }),
      new Costume("k", "./Cloudlist/costumes/k.svg", { x: 0, y: 0 }),
      new Costume("l", "./Cloudlist/costumes/l.svg", { x: 0, y: 0 }),
      new Costume("m", "./Cloudlist/costumes/m.svg", { x: 0, y: 0 }),
      new Costume("n", "./Cloudlist/costumes/n.svg", { x: 0, y: 0 }),
      new Costume("o", "./Cloudlist/costumes/o.svg", { x: 0, y: 0 }),
      new Costume("p", "./Cloudlist/costumes/p.svg", { x: 0, y: 0 }),
      new Costume("q", "./Cloudlist/costumes/q.svg", { x: 0, y: 0 }),
      new Costume("r", "./Cloudlist/costumes/r.svg", { x: 0, y: 0 }),
      new Costume("s", "./Cloudlist/costumes/s.svg", { x: 0, y: 0 }),
      new Costume("t", "./Cloudlist/costumes/t.svg", { x: 0, y: 0 }),
      new Costume("u", "./Cloudlist/costumes/u.svg", { x: 0, y: 0 }),
      new Costume("v", "./Cloudlist/costumes/v.svg", { x: 0, y: 0 }),
      new Costume("w", "./Cloudlist/costumes/w.svg", { x: 0, y: 0 }),
      new Costume("x", "./Cloudlist/costumes/x.svg", { x: 0, y: 0 }),
      new Costume("y", "./Cloudlist/costumes/y.svg", { x: 0, y: 0 }),
      new Costume("z", "./Cloudlist/costumes/z.svg", { x: 0, y: 0 }),
      new Costume("uA", "./Cloudlist/costumes/uA.svg", { x: 0, y: 0 }),
      new Costume("uB", "./Cloudlist/costumes/uB.svg", { x: 0, y: 0 }),
      new Costume("uC", "./Cloudlist/costumes/uC.svg", { x: 0, y: 0 }),
      new Costume("uD", "./Cloudlist/costumes/uD.svg", { x: 0, y: 0 }),
      new Costume("uE", "./Cloudlist/costumes/uE.svg", { x: 0, y: 0 }),
      new Costume("uF", "./Cloudlist/costumes/uF.svg", { x: 0, y: 0 }),
      new Costume("uG", "./Cloudlist/costumes/uG.svg", { x: 0, y: 0 }),
      new Costume("uH", "./Cloudlist/costumes/uH.svg", { x: 0, y: 0 }),
      new Costume("uI", "./Cloudlist/costumes/uI.svg", { x: 0, y: 0 }),
      new Costume("uJ", "./Cloudlist/costumes/uJ.svg", { x: 0, y: 0 }),
      new Costume("uK", "./Cloudlist/costumes/uK.svg", { x: 0, y: 0 }),
      new Costume("uL", "./Cloudlist/costumes/uL.svg", { x: 0, y: 0 }),
      new Costume("uM", "./Cloudlist/costumes/uM.svg", { x: 0, y: 0 }),
      new Costume("uN", "./Cloudlist/costumes/uN.svg", { x: 0, y: 0 }),
      new Costume("uO", "./Cloudlist/costumes/uO.svg", { x: 0, y: 0 }),
      new Costume("uP", "./Cloudlist/costumes/uP.svg", { x: 0, y: 0 }),
      new Costume("uQ", "./Cloudlist/costumes/uQ.svg", { x: 0, y: 0 }),
      new Costume("uR", "./Cloudlist/costumes/uR.svg", { x: 0, y: 0 }),
      new Costume("uS", "./Cloudlist/costumes/uS.svg", { x: 0, y: 0 }),
      new Costume("uT", "./Cloudlist/costumes/uT.svg", { x: 0, y: 0 }),
      new Costume("uU", "./Cloudlist/costumes/uU.svg", { x: 0, y: 0 }),
      new Costume("uW", "./Cloudlist/costumes/uW.svg", { x: 0, y: 0 }),
      new Costume("uX", "./Cloudlist/costumes/uX.svg", { x: 0, y: 0 }),
      new Costume("uY", "./Cloudlist/costumes/uY.svg", { x: 0, y: 0 }),
      new Costume("uZ", "./Cloudlist/costumes/uZ.svg", { x: 0, y: 0 }),
      new Costume("Error!", "./Cloudlist/costumes/Error!.svg", {
        x: 241,
        y: 180,
      }),
      new Costume("saved", "./Cloudlist/costumes/saved.svg", { x: 109, y: 21 }),
    ];

    this.sounds = [new Sound("meow", "./Cloudlist/sounds/meow.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "getcloud" },
        this.whenIReceiveGetcloud
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.BROADCAST, { name: "GO" }, this.whenIReceiveGo),
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed
      ),
    ];

    this.vars.data = "false";
    this.vars.clLetterscode =
      "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz@-_?";
    this.vars.clOnetime = null;
    this.vars.cl1 = 687;
    this.vars.cl2 = 0;
    this.vars.clReturn = "true";
    this.vars._1 = 1;
    this.vars.cl3 = 1;
    this.vars._2 = 3;
    this.vars.bgmlag = 0;
    this.vars.cloudvarlength = "Cloudlength : 9948";
    this.vars.savedataOnetime = [882560, 0, 7992669234];

    this.watchers.cloudvarlength = new Watcher({
      label: "Cloudlist: CloudVarLength",
      style: "large",
      visible: false,
      value: () => this.vars.cloudvarlength,
      x: 458,
      y: 159,
    });
  }

  *showCloudlist() {
    this.vars.clLetterscode =
      "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz@-_? ";
    this.vars.clOnetime = this.stage.vars._1;
    this.vars.cl1 = 0;
    this.stage.vars.cloudlist = [];
    for (let i = 0; i < Math.ceil(this.vars.clOnetime.length / 2); i++) {
      this.vars.cl1 += 2;
      if (
        this.toNumber(
          this.letterOf(this.vars.clOnetime, this.toNumber(this.vars.cl1) - 2) +
            this.letterOf(this.vars.clOnetime, this.vars.cl1 - 1)
        ) === 0
      ) {
        this.stage.vars.cloudlist.push("");
      } else {
        this.stage.vars.cloudlist.splice(
          "last",
          1,
          this.toString(
            this.itemOf(
              this.stage.vars.cloudlist,
              this.stage.vars.cloudlist.length - 1
            )
          ) +
            this.letterOf(
              this.vars.clLetterscode,
              this.letterOf(
                this.vars.clOnetime,
                this.toNumber(this.vars.cl1) - 2
              ) +
                this.letterOf(this.vars.clOnetime, this.vars.cl1 - 1) -
                1
            )
        );
      }
      yield;
    }
    this.vars.clReturn = "true";
  }

  *loadCloudlist() {
    this.vars.clLetterscode =
      "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz@-_?";
    this.vars.cl1 = 0;
    this.vars.clOnetime = "";
    for (let i = 0; i < this.stage.vars.cloudlist.length; i++) {
      this.vars.cl1++;
      this.vars.cl2 = 0;
      this.vars.clOnetime = this.toString(this.vars.clOnetime) + "00";
      for (
        let i = 0;
        i < this.itemOf(this.stage.vars.cloudlist, this.vars.cl1 - 1).length;
        i++
      ) {
        this.vars.cl2++;
        this.vars.cl3 = 1;
        while (
          !(
            this.compare(
              this.letterOf(this.vars.clLetterscode, this.vars.cl3 - 1),
              this.letterOf(
                this.itemOf(this.stage.vars.cloudlist, this.vars.cl1 - 1),
                this.vars.cl2 - 1
              )
            ) === 0 ||
            this.compare(this.vars.clLetterscode.length - 1, this.vars.cl3) < 0
          )
        ) {
          this.vars.cl3++;
          yield;
        }
        this.costume = "CL by MMGISS";
        this.costume = this.letterOf(
          this.itemOf(this.stage.vars.cloudlist, this.vars.cl1 - 1),
          this.vars.cl2 - 1
        );
        this.vars.cl3 =
          this.toNumber(this.vars.cl3) +
          this.toNumber(
            this.compare(1, this.costumeNumber) < 0 &&
              !(
                this.compare(
                  this.letterOf(
                    this.itemOf(this.stage.vars.cloudlist, this.vars.cl1 - 1),
                    this.vars.cl2 - 1
                  ),
                  this.toNumber(
                    this.letterOf(
                      this.itemOf(this.stage.vars.cloudlist, this.vars.cl1 - 1),
                      this.vars.cl2 - 1
                    )
                  ) * 1
                ) === 0
              )
          ) *
            26;
        if (this.vars.cl3.length === 1) {
          this.vars.cl3 = "0" + this.toString(this.vars.cl3);
        }
        this.vars.clOnetime =
          this.toString(this.vars.clOnetime) + this.toString(this.vars.cl3);
        yield;
      }
      yield;
    }
    this.stage.vars._1 = this.vars.clOnetime;
    this.vars.clReturn = "true";
  }

  *deleteDataOf(username) {
    this.vars._1 = this.stage.vars.cloudlist.length - 3;
    while (
      !(
        this.compare(
          this.itemOf(this.stage.vars.cloudlist, this.vars._1 - 1),
          "@" + this.toString(username)
        ) === 0
      )
    ) {
      this.vars._1--;
      yield;
    }
    this.stage.vars.cloudlist.splice(this.vars._1 - 1, 1);
    this.stage.vars.cloudlist.splice(this.vars._1 - 1, 1);
    this.stage.vars.cloudlist.splice(this.vars._1 - 1, 1);
    this.stage.vars.cloudlist.splice(this.vars._1 - 1, 1);
  }

  *whenGreenFlagClicked() {
    this.goto(0, 0);
    this.visible = false;
    yield* this.showCloudlist();
    yield* this.getDataOf(3, /* no username */ "");
    if (
      this.toString(this.vars.data) === "false" ||
      this.compare(
        this.vars.data,
        (((new Date().getTime() - new Date(2000, 0, 1)) / 1000 / 60 +
          new Date().getTimezoneOffset()) /
          60 /
          24) *
          86400000
      ) < 0
    ) {
      yield* this.getDataOf(2, /* no username */ "");
      this.stage.vars.nextdate = this.vars.data;
      yield* this.getDataOf(1, /* no username */ "");
      this.stage.vars.chipsHidden = this.vars.data;
      if (this.toString(this.vars.data) === "false") {
        yield* this.saveDataAtWithUser(1000000, 1, /* no username */ "");
        yield* this.saveandcheckcloud();
        this.stage.vars.chipsHidden = 1000000;
      }
      yield* this.wait(0.5);
      this.broadcast("GO");
      while (true) {
        while (!(this.toNumber(this.stage.vars.spinning) === 1)) {
          yield;
        }
        while (!(this.toNumber(this.stage.vars.spinning) === 0)) {
          yield;
        }
        this.vars.bgmlag = this.timer;
        yield* this.showCloudlist();
        yield* this.saveDataAtWithUser(
          Math.round(this.toNumber(this.stage.vars.chipsHidden)),
          1,
          /* no username */ ""
        );
        yield* this.saveDataAtWithUser(
          Math.round(
            (((new Date().getTime() - new Date(2000, 0, 1)) / 1000 / 60 +
              new Date().getTimezoneOffset()) /
              60 /
              24) *
              864000
          ),
          3,
          /* no username */ ""
        );
        if (!(this.compare(this.stage.vars.chipsHidden, 0) > 0)) {
          yield* this.saveDataAtWithUser(
            this.toString(new Date().getFullYear()) +
              this.toString(new Date().getMonth() + 1) +
              this.toString(new Date().getDate()),
            2,
            /* no username */ ""
          );
        }
        yield* this.saveandcheckcloud();
        this.vars.bgmlag = this.timer - this.toNumber(this.vars.bgmlag);
        this.stage.vars.bgmtime += this.toNumber(this.vars.bgmlag);
        this.createClone();
        yield;
      }
    } else {
      this.visible = true;
      this.effects.ghost = 100;
      for (let i = 0; i < 20; i++) {
        this.effects.ghost -= 5;
        this.moveAhead();
        yield;
      }
    }
  }

  *saveDataAtWithUser(data, num, username) {
    if (
      this.arrayIncludes(
        this.stage.vars.cloudlist,
        "@" + this.toString(username)
      )
    ) {
      this.vars._1 = 1;
      while (
        !(
          this.compare(
            this.itemOf(this.stage.vars.cloudlist, this.vars._1 - 1),
            "@" + this.toString(username)
          ) === 0
        )
      ) {
        this.vars._1 += 4;
        yield;
      }
      this.vars.savedataOnetime = [];
      this.vars._2 = 0;
      for (let i = 0; i < 3; i++) {
        this.vars._2++;
        if (this.compare(num, this.vars._2) === 0) {
          this.vars.savedataOnetime.push(data);
        } else {
          this.vars.savedataOnetime.push(
            this.itemOf(
              this.stage.vars.cloudlist,
              this.toNumber(this.vars._1) + this.toNumber(this.vars._2) - 1
            )
          );
        }
        yield;
      }
      yield* this.deleteDataOf(username);
    } else {
      this.vars._2 = 0;
      for (let i = 0; i < 3; i++) {
        this.vars._2++;
        if (this.compare(num, this.vars._2) === 0) {
          this.vars.savedataOnetime.push(data);
        } else {
          this.vars.savedataOnetime.push("");
        }
        yield;
      }
    }
    this.stage.vars.cloudlist.splice(
      0,
      0,
      this.itemOf(this.vars.savedataOnetime, 2)
    );
    this.stage.vars.cloudlist.splice(
      0,
      0,
      this.itemOf(this.vars.savedataOnetime, 1)
    );
    this.stage.vars.cloudlist.splice(
      0,
      0,
      this.itemOf(this.vars.savedataOnetime, 0)
    );
    this.stage.vars.cloudlist.splice(0, 0, "@" + this.toString(username));
  }

  *getDataOf(num, username) {
    if (
      this.arrayIncludes(
        this.stage.vars.cloudlist,
        "@" + this.toString(username)
      )
    ) {
      this.vars._1 = 1;
      while (
        !(
          this.compare(
            this.itemOf(this.stage.vars.cloudlist, this.vars._1 - 1),
            "@" + this.toString(username)
          ) === 0
        )
      ) {
        this.vars._1 += 4;
        yield;
      }
      this.vars.data = this.itemOf(
        this.stage.vars.cloudlist,
        this.toNumber(this.vars._1) + this.toNumber(num) - 1
      );
    } else {
      this.vars.data = "false";
    }
  }

  *whenIReceiveGetcloud() {
    for (let i = 0; i < 1; i++) {
      this.deleteThisClone();
      yield;
    }
    yield* this.showCloudlist();
  }

  *startAsClone() {
    this.costume = "saved";
    this.goto(-240, -162.5);
    this.visible = true;
    this.effects.ghost = 100;
    for (let i = 0; i < 35; i++) {
      this.effects.ghost -= 5;
      this.moveAhead();
      this.x += (-135 - this.x) / 7.5;
      yield;
    }
    for (let i = 0; i < 10; i++) {
      this.effects.ghost += 10;
      this.x += (-135 - this.x) / 7.5;
      yield;
    }
    this.visible = false;
    this.deleteThisClone();
  }

  *showchips() {
    this.stage.vars.chips = "";
    this.vars._1 = Math.round(
      this.toNumber(this.stage.vars.chipsHidden)
    ).length;
    this.vars._2 = 0;
    for (
      let i = 0;
      i < Math.round(this.toNumber(this.stage.vars.chipsHidden)).length;
      i++
    ) {
      this.stage.vars.chips =
        this.letterOf(
          Math.round(this.toNumber(this.stage.vars.chipsHidden)),
          this.vars._1 - 1
        ) + this.toString(this.stage.vars.chips);
      this.vars._1--;
      this.vars._2++;
      if (
        this.toNumber(this.vars._2) % 3 === 0 &&
        this.compare(this.vars._1, 0) > 0
      ) {
        this.stage.vars.chips = "," + this.toString(this.stage.vars.chips);
      }
      yield;
    }
  }

  *whenIReceiveGo() {
    while (true) {
      if (
        !(this.toNumber(this.stage.vars.nextdate) === 0) &&
        this.compare(
          this.stage.vars.nextdate,
          this.toString(new Date().getFullYear()) +
            this.toString(new Date().getMonth() + 1) +
            this.toString(new Date().getDate())
        ) < 0
      ) {
        yield* this.saveDataAtWithUser(1000000, 1, /* no username */ "");
        yield* this.saveDataAtWithUser(0, 2, /* no username */ "");
        this.stage.vars.chipsHidden = 1000000;
        this.stage.vars.nextdate = null;
        yield* this.showchips();
      }
      yield;
    }
  }

  *saveandcheckcloud() {
    yield* this.loadCloudlist();
    if (!(this.compare(10000, this.stage.vars._1.length) > 0)) {
      this.stage.vars.cloudlist.splice(this.stage.vars.cloudlist.length - 1, 1);
      this.stage.vars.cloudlist.splice(this.stage.vars.cloudlist.length - 1, 1);
      this.stage.vars.cloudlist.splice(this.stage.vars.cloudlist.length - 1, 1);
      this.stage.vars.cloudlist.splice(this.stage.vars.cloudlist.length - 1, 1);
      yield* this.loadCloudlist();
    }
  }

  *whenKeySpacePressed() {
    if (/* no username */ "" === "MMGISS") {
      this.vars.cloudvarlength =
        "Cloudlength : " + this.toString(this.stage.vars._1.length);
      this.stage.watchers.cloudlist.visible = true;
      this.stage.watchers._1.visible = true;
      this.watchers.cloudvarlength.visible = true;
      while (!!this.keyPressed("space")) {
        yield;
      }
      while (!this.keyPressed("space")) {
        yield;
      }
      this.stage.watchers.cloudlist.visible = false;
      this.stage.watchers._1.visible = false;
      this.watchers.cloudvarlength.visible = false;
      while (!!this.keyPressed("space")) {
        yield;
      }
    }
  }
}
