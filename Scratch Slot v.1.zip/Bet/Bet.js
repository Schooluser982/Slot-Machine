/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Bet extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("240", "./Bet/costumes/240.svg", { x: 44, y: 22 }),
      new Costume("480", "./Bet/costumes/480.svg", { x: 44, y: 22 }),
      new Costume("960", "./Bet/costumes/960.svg", { x: 44, y: 22 }),
      new Costume("1600", "./Bet/costumes/1600.svg", { x: 44, y: 22 }),
      new Costume("2400", "./Bet/costumes/2400.svg", { x: 44, y: 22 }),
    ];

    this.sounds = [
      new Sound(
        "se_maoudamashii_se_pc01.mp3",
        "./Bet/sounds/se_maoudamashii_se_pc01.mp3.wav"
      ),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "GO" }, this.whenIReceiveGo),
    ];

    this.vars.bet = 1;
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveGo() {
    this.goto(180, -145);
    this.effects.clear();
    this.visible = true;
    this.vars.bet = 1;
    while (true) {
      this.moveAhead();
      this.costume = this.stage.vars.betperline;
      if (this.toNumber(this.stage.vars.spinning) === 0) {
        if (this.touching("mouse")) {
          if (this.mouse.down) {
            yield* this.startSound("se_maoudamashii_se_pc01.mp3");
            this.vars.bet = (this.toNumber(this.vars.bet) % 5) + 1;
            this.stage.vars.betperline = this.itemOf(
              this.stage.vars.bets,
              this.vars.bet - 1
            );
            this.costume = this.stage.vars.betperline;
            this.effects.brightness = 10;
            while (!!this.mouse.down) {
              yield;
            }
          } else {
            this.effects.brightness = 25;
          }
        } else {
          this.effects.brightness = 0;
        }
      } else {
        this.effects.brightness = -25;
      }
      yield;
    }
  }
}
