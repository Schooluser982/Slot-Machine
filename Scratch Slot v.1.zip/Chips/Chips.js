/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Chips extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./Chips/costumes/1.svg", { x: 21, y: 13 }),
      new Costume("2", "./Chips/costumes/2.svg", { x: 21, y: 13 }),
      new Costume("3", "./Chips/costumes/3.svg", { x: 21, y: 13 }),
      new Costume("4", "./Chips/costumes/4.svg", { x: 21, y: 13 }),
      new Costume("5", "./Chips/costumes/5.svg", { x: 21, y: 13 }),
      new Costume("6", "./Chips/costumes/6.svg", { x: 21, y: 13 }),
      new Costume("7", "./Chips/costumes/7.svg", { x: 21, y: 13 }),
      new Costume("8", "./Chips/costumes/8.svg", { x: 21, y: 13 }),
      new Costume("9", "./Chips/costumes/9.svg", { x: 21, y: 13 }),
      new Costume("10", "./Chips/costumes/10.svg", { x: 21, y: 13 }),
      new Costume("11", "./Chips/costumes/11.svg", { x: 21, y: 13 }),
      new Costume("12", "./Chips/costumes/12.svg", { x: 21, y: 13 }),
      new Costume("13", "./Chips/costumes/13.svg", { x: 21, y: 13 }),
      new Costume("14", "./Chips/costumes/14.svg", { x: 21, y: 13 }),
      new Costume("15", "./Chips/costumes/15.svg", { x: 21, y: 13 }),
      new Costume("16", "./Chips/costumes/16.svg", { x: 21, y: 13 }),
      new Costume("17", "./Chips/costumes/17.svg", { x: 21, y: 13 }),
      new Costume("18", "./Chips/costumes/18.svg", { x: 21, y: 13 }),
      new Costume("19", "./Chips/costumes/19.svg", { x: 21, y: 13 }),
      new Costume("20", "./Chips/costumes/20.svg", { x: 21, y: 13 }),
      new Costume("21", "./Chips/costumes/21.svg", { x: 21, y: 13 }),
      new Costume("22", "./Chips/costumes/22.svg", { x: 21, y: 13 }),
      new Costume("23", "./Chips/costumes/23.svg", { x: 21, y: 13 }),
      new Costume("24", "./Chips/costumes/24.svg", { x: 21, y: 13 }),
      new Costume("25", "./Chips/costumes/25.svg", { x: 21, y: 13 }),
    ];

    this.sounds = [new Sound("ポップ", "./Chips/sounds/ポップ.wav")];

    this.triggers = [
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "GO" }, this.whenIReceiveGo),
    ];

    this.vars._1 = 25;
    this.vars._2 = 0;
    this.vars.hittingresult = 0;
    this.vars._3 = 2;
  }

  *startAsClone() {
    this.moveAhead();
    this.visible = true;
    this.vars._2 = 0;
    while (true) {
      yield* this.hittingcheck();
      if (this.compare(this.vars.hittingresult, 0) > 0) {
        if (this.compare(this.vars._1, this.stage.vars.checkingpos) === 0) {
          this.vars._2 += (50 - this.toNumber(this.vars._2)) / 5;
        } else {
          this.vars._2 += (20 - this.toNumber(this.vars._2)) / 5;
        }
      } else {
        this.vars._2 += (0 - this.toNumber(this.vars._2)) / 5;
      }
      this.effects.brightness = this.toNumber(this.vars._2);
      yield;
    }
  }

  *hittingcheck() {
    this.vars.hittingresult = 0;
    this.vars._3 = 3;
    for (let i = 0; i < this.stage.vars.results.length / 3; i++) {
      this.vars.hittingresult += this.toNumber(
        this.compare(
          this.itemOf(this.stage.vars.results, this.vars._3 - 1),
          this.vars._1
        ) === 0
      );
      this.vars._3 += 3;
      yield;
    }
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.size = 80;
  }

  *whenIReceiveGo() {
    yield* this.init();
  }

  *init() {
    this.goto(-215, 98 + this.toNumber(this.stage.vars.positiony));
    this.costume = 1;
    this.vars._1 = 0;
    for (let i = 0; i < 13; i++) {
      this.vars._1++;
      this.createClone();
      this.costumeNumber++;
      this.y -= 16.5;
      yield;
    }
    this.goto(215, 89.75 + this.toNumber(this.stage.vars.positiony));
    for (let i = 0; i < 12; i++) {
      this.vars._1++;
      this.createClone();
      this.costumeNumber++;
      this.y -= 16.5;
      yield;
    }
  }
}
